import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { CreditCard, Loader2, ShieldCheck } from "lucide-react";

interface DealAnalysisPaywallProps {
  dealId: string;
  overpayEstimate?: number;
}

export function DealAnalysisPaywall({ dealId, overpayEstimate }: DealAnalysisPaywallProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleUnlock = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.functions.invoke("create-deal-analysis-checkout", {
        body: { dealId },
      });

      if (error) throw error;

      if (data?.alreadyUnlocked) {
        toast({
          title: "You're already unlocked",
          description: "Refreshing your deal access now.",
        });
        window.location.href = `/deal-room?dealId=${dealId}&checkout=success`;
        return;
      }

      if (!data?.url) {
        throw new Error("Missing checkout URL");
      }

      window.location.href = data.url;
    } catch (err: any) {
      console.error("Unlock error:", err);
      toast({
        title: "Checkout Error",
        description: err?.message ?? "Unable to start checkout",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border bg-card p-6 shadow-sm">
      <div className="flex items-start gap-3">
        <ShieldCheck className="h-6 w-6 text-primary mt-0.5" />
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-foreground">Unlock Full Deal Analysis</h3>
          <p className="text-sm text-muted-foreground mt-1">
            One-time purchase for this deal. No subscriptions. No auto-renew.
          </p>
        </div>
      </div>

      {typeof overpayEstimate === "number" && (
        <div className="mt-4 rounded-xl bg-muted p-4">
          <p className="text-sm text-muted-foreground">Potential overpayment</p>
          <p className="text-2xl font-bold text-foreground">${overpayEstimate.toLocaleString()}</p>
        </div>
      )}

      <ul className="mt-4 space-y-2 text-sm text-foreground/90">
        <li>• Fee-by-fee breakdown (legit vs junk)</li>
        <li>• Correct monthly payment (no dealer math)</li>
        <li>• Deal score details + red flags</li>
        <li>• Dealer-ready negotiation scripts</li>
        <li>• Unlimited re-analysis for this deal</li>
      </ul>

      <div className="mt-5 flex items-center justify-between">
        <div>
          <div className="text-lg font-semibold">$9.99</div>
          <div className="text-xs text-muted-foreground">One-time · per deal</div>
        </div>

        <Button onClick={handleUnlock} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Redirecting…
            </>
          ) : (
            <>
              <CreditCard className="h-4 w-4 mr-2" />
              Unlock for $9.99
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
