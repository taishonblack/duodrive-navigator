import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : "";
  console.log(`[CREATE-DEAL-ANALYSIS-CHECKOUT] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { dealId } = await req.json();
    if (!dealId) {
      return new Response(JSON.stringify({ error: "Missing dealId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const appUrl = Deno.env.get("APP_URL");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!stripeKey || !appUrl || !supabaseUrl || !serviceKey) {
      return new Response(JSON.stringify({ error: "Missing server env vars" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const stripe = new Stripe(stripeKey, { apiVersion: "2024-06-20" });

    // Use the user's JWT to identify them, but use service role for DB (webhook-friendly).
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabaseAuth = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: authData, error: authErr } = await supabaseAuth.auth.getUser();
    if (authErr || !authData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = authData.user.id;

    const supabase = createClient(supabaseUrl, serviceKey);

    // Validate: deal exists and belongs to this user
    const { data: deal, error: dealErr } = await supabase
      .from("deals")
      .select("id, user_id")
      .eq("id", dealId)
      .single();

    if (dealErr || !deal) {
      return new Response(JSON.stringify({ error: "Deal not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (deal.user_id !== userId) {
      return new Response(JSON.stringify({ error: "Forbidden" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Ensure entitlement row exists (older deals)
    await supabase.from("deal_entitlements").upsert({
      deal_id: dealId,
      user_id: userId,
      status: "locked",
    }, { onConflict: "deal_id" });

    const { data: ent } = await supabase
      .from("deal_entitlements")
      .select("status")
      .eq("deal_id", dealId)
      .single();

    if (ent?.status === "unlocked") {
      return new Response(JSON.stringify({ alreadyUnlocked: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create checkout session ($9.99 one-time)
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: "usd",
            unit_amount: 999,
            product_data: {
              name: "DuoDrive Deal Analysis",
              description: "Unlock full deal analysis for this vehicle (one-time)",
            },
          },
          quantity: 1,
        },
      ],
      success_url: `${appUrl}/deal-room?dealId=${dealId}&checkout=success`,
      cancel_url: `${appUrl}/deal-room?dealId=${dealId}&checkout=canceled`,
      metadata: {
        deal_id: dealId,
        user_id: userId,
        product: "deal_analysis_v1",
      },
    });

    logStep("Created checkout session", { sessionId: session.id, dealId });

    await supabase
      .from("deal_entitlements")
      .update({ stripe_session_id: session.id })
      .eq("deal_id", dealId);

    return new Response(JSON.stringify({ url: session.url, sessionId: session.id }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    logStep("Error", { message: (error as Error).message });
    return new Response(JSON.stringify({ error: "Internal error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
