import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[STRIPE-WEBHOOK] ${step}${detailsStr}`);
};

// Helper to send payment notification emails
const sendPaymentNotification = async (
  supabaseUrl: string,
  supabaseKey: string,
  requestId: string,
  notificationType: "payment_received" | "payment_failed" | "refund_processed",
  amount?: number,
  sessionType?: string
) => {
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/send-payment-notification`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ requestId, notificationType, amount, sessionType }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      logStep("Failed to send notification", { error: errorText });
    } else {
      logStep("Notification sent", { type: notificationType });
    }
  } catch (error) {
    logStep("Error sending notification", { error: String(error) });
  }
};

serve(async (req) => {
  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    logStep("Webhook received");

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    // Get the raw body for signature verification
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");
    
    // Get webhook secret if configured (optional but recommended for production)
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
    
    let event: Stripe.Event;
    
    if (webhookSecret && signature) {
      try {
        event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
        logStep("Signature verified");
      } catch (err) {
        logStep("Signature verification failed", { error: String(err) });
        return new Response(JSON.stringify({ error: "Webhook signature verification failed" }), {
          status: 400,
        });
      }
    } else {
      // Parse without verification (for development)
      event = JSON.parse(body);
      logStep("Parsed event without signature verification (dev mode)");
    }

    logStep("Processing event", { type: event.type, id: event.id });

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const requestId = session.metadata?.request_id;
        const sessionType = session.metadata?.session_type;
        const customerId = session.customer as string;
        const dealId = session.metadata?.deal_id;
        
        logStep("Checkout completed", { requestId, sessionType, customerId, dealId });


// DuoDrive v2: one-time deal analysis unlock
if (dealId) {
  logStep("Unlocking deal entitlement", { dealId });
  const { error: entError } = await supabaseClient
    .from("deal_entitlements")
    .update({
      status: "unlocked",
      stripe_payment_intent_id: session.payment_intent as string,
      unlocked_at: new Date().toISOString(),
    })
    .eq("deal_id", dealId);

  if (entError) {
    logStep("Failed to unlock entitlement", { dealId, error: entError.message });
  } else {
    logStep("Entitlement unlocked", { dealId });
  }
}

        if (requestId) {
          // Determine payment status based on session type
          const paymentStatus = sessionType === "video" ? "deposit_paid" : "fully_paid";
          
          const { error } = await supabaseClient
            .from("coaching_requests")
            .update({
              payment_status: paymentStatus,
              stripe_customer_id: customerId,
              stripe_payment_intent_id: session.payment_intent as string,
              deposit_paid_at: new Date().toISOString(),
            })
            .eq("id", requestId);

          if (error) {
            logStep("Failed to update request", { error: error.message });
          } else {
            logStep("Updated request payment status", { requestId, paymentStatus });
            
            // Send payment received email
            await sendPaymentNotification(
              Deno.env.get("SUPABASE_URL") ?? "",
              Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
              requestId,
              "payment_received",
              session.amount_total ?? undefined,
              sessionType
            );
          }
        }
        break;
      }

      case "payment_intent.succeeded": {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        const requestId = paymentIntent.metadata?.request_id;
        const chargeType = paymentIntent.metadata?.charge_type;
        
        logStep("Payment succeeded", { requestId, chargeType });

        if (requestId && chargeType === "concierge_remaining") {
          const { error } = await supabaseClient
            .from("coaching_requests")
            .update({
              payment_status: "fully_paid",
              remaining_charged_at: new Date().toISOString(),
            })
            .eq("id", requestId);

          if (error) {
            logStep("Failed to update remaining payment", { error: error.message });
          } else {
            logStep("Updated to fully paid", { requestId });
          }
        }
        break;
      }

      case "payment_intent.payment_failed": {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;
        const requestId = paymentIntent.metadata?.request_id;
        
        logStep("Payment failed", { requestId });

        if (requestId) {
          const { error } = await supabaseClient
            .from("coaching_requests")
            .update({ payment_status: "failed" })
            .eq("id", requestId);

          if (error) {
            logStep("Failed to update failed status", { error: error.message });
          } else {
            // Send payment failed email
            await sendPaymentNotification(
              Deno.env.get("SUPABASE_URL") ?? "",
              Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
              requestId,
              "payment_failed"
            );
          }
        }
        break;
      }

      case "charge.refunded": {
        const charge = event.data.object as Stripe.Charge;
        const paymentIntentId = charge.payment_intent as string;
        
        logStep("Charge refunded", { paymentIntentId });

        if (paymentIntentId) {
          // First get the request to send notification
          const { data: requestData } = await supabaseClient
            .from("coaching_requests")
            .select("id, session_type")
            .eq("stripe_payment_intent_id", paymentIntentId)
            .single();

          const { error } = await supabaseClient
            .from("coaching_requests")
            .update({ payment_status: "refunded" })
            .eq("stripe_payment_intent_id", paymentIntentId);

          if (error) {
            logStep("Failed to update refund status", { error: error.message });
          } else if (requestData) {
            // Send refund processed email
            await sendPaymentNotification(
              Deno.env.get("SUPABASE_URL") ?? "",
              Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
              requestData.id,
              "refund_processed",
              charge.amount_refunded,
              requestData.session_type
            );
          }
        }
        break;
      }

      default:
        logStep("Unhandled event type", { type: event.type });
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { "Content-Type": "application/json" },
      status: 500,
    });
  }
});
