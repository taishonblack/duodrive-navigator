-- DuoDrive v2: one-time $9.99 deal analysis entitlements

-- 1) Status enum
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'deal_entitlement_status') THEN
    CREATE TYPE public.deal_entitlement_status AS ENUM ('locked', 'unlocked');
  END IF;
END$$;

-- 2) Entitlements table (one row per deal)
CREATE TABLE IF NOT EXISTS public.deal_entitlements (
  deal_id UUID PRIMARY KEY REFERENCES public.deals(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status public.deal_entitlement_status NOT NULL DEFAULT 'locked',
  stripe_session_id TEXT,
  stripe_payment_intent_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  unlocked_at TIMESTAMPTZ
);

ALTER TABLE public.deal_entitlements ENABLE ROW LEVEL SECURITY;

-- Users can view their own entitlement
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='deal_entitlements' AND policyname='Users can view their own deal entitlements'
  ) THEN
    CREATE POLICY "Users can view their own deal entitlements"
    ON public.deal_entitlements
    FOR SELECT
    USING (auth.uid() = user_id);
  END IF;
END$$;

-- Users can insert their own entitlement (rare fallback); typically done by trigger / service role.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='deal_entitlements' AND policyname='Users can create their own deal entitlements'
  ) THEN
    CREATE POLICY "Users can create their own deal entitlements"
    ON public.deal_entitlements
    FOR INSERT
    WITH CHECK (auth.uid() = user_id);
  END IF;
END$$;

-- Users can update status only for their own entitlement (status remains validated server-side via webhook, but harmless to allow limited updates)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='deal_entitlements' AND policyname='Users can update their own deal entitlements'
  ) THEN
    CREATE POLICY "Users can update their own deal entitlements"
    ON public.deal_entitlements
    FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);
  END IF;
END$$;

-- 3) Backfill: ensure existing deals get an entitlement row (locked)
INSERT INTO public.deal_entitlements (deal_id, user_id, status)
SELECT d.id, d.user_id, 'locked'::public.deal_entitlement_status
FROM public.deals d
LEFT JOIN public.deal_entitlements e ON e.deal_id = d.id
WHERE e.deal_id IS NULL;

-- 4) Trigger: create entitlement row automatically when a deal is inserted
CREATE OR REPLACE FUNCTION public.create_deal_entitlement()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.deal_entitlements (deal_id, user_id, status)
  VALUES (NEW.id, NEW.user_id, 'locked')
  ON CONFLICT (deal_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_deal_created_create_entitlement ON public.deals;
CREATE TRIGGER on_deal_created_create_entitlement
AFTER INSERT ON public.deals
FOR EACH ROW EXECUTE FUNCTION public.create_deal_entitlement();
